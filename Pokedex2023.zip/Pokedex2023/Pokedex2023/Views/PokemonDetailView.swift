//
//  PokemonDetailView.swift
//  Pokedex2023
//
//  Created by Da Zhuo Xie on 2023-10-26.
//

import SwiftUI

struct PokemonDetailView: View {
    @EnvironmentObject var viewModel: PokemonViewModel
    let pokemon: Pokemon
    var body: some View {
        VStack{
            
            PokemonView(pokemon: pokemon)
            
            VStack(spacing: 10) {
                Text("**ID**: \(viewModel.pokemonDetails?.id ?? 0)")
                if let height = viewModel.pokemonDetails?.height {
                        Text("**Height**: \(viewModel.formatHeightWeight(value: height))")
                    } else {
                        Text("**Height**: N/A")
                    }
                    if let weight = viewModel.pokemonDetails?.weight {
                        Text("**Weight**: \(viewModel.formatHeightWeight(value: weight))")
                    } else {
                        Text("**Weight**: N/A")
                    }

            }
            
        }
        .onAppear(){
            viewModel.getDetails(pokemon: pokemon)
        }
    }
}

struct PokemonDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PokemonDetailView(pokemon: Pokemon.samplePokemon)
            .environmentObject(PokemonViewModel())
    }
}
