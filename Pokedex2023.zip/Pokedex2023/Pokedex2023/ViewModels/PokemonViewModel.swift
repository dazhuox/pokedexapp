//
//  PokemonViewModel.swift
//  Pokedex2023
//
//  Created by Da Zhuo Xie on 2023-10-23.
//

import Foundation

final class PokemonViewModel: ObservableObject {
    private let pokemonService = PokemonAccessService()
    
    @Published var pokemonList = [Pokemon]()
    @Published var searchText = ""
    @Published var pokemonDetails : DetailedPokemon?
    
    var filteredPokemon: [Pokemon] {
        return searchText == "" ? pokemonList : pokemonList.filter{
            $0.name.contains(searchText.lowercased())
        }
    }
    
    init() {
        pokemonService.get150Pokemon{ poke in
            DispatchQueue.main.async {
                self.pokemonList = poke
            }
            
        }
        
        print(pokemonList.count)
    }
    
    func getPokemonId(pokemon: Pokemon) -> Int{
        if let index = pokemonList.firstIndex(of: pokemon){
            return index + 1
        }
        return 0
    }
    
    func getPokemonById(id: Int) {
       pokemonService.getDetailedPokemon(id: id) { data in
           DispatchQueue.main.async {
               self.pokemonDetails = data
           }
       }
    }
    
    func getDetails(pokemon: Pokemon) {
        let id = getPokemonId(pokemon: pokemon)
        
        pokemonDetails = DetailedPokemon(id: 0, height: 0, weight: 0)
        pokemonService.getDetailedPokemon(id: id) { data in
            DispatchQueue.main.async {
                self.pokemonDetails = data
            }
        }
    }
    
    func formatHeightWeight(value: Int) -> String{
        let dValue = Double(value)
        let string = String(format: "%.2f", dValue / 10)
        
        return string
    }
}
