//
//  Pokedex2023App.swift
//  Pokedex2023
//
//  Created by Da Zhuo Xie on 2023-10-23.
//

import SwiftUI

@main
struct Pokedex2023App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
