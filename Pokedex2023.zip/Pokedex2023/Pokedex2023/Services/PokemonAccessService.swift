//
//  PokemonAccessService.swift
//  Pokedex2023
//
//  Created by Da Zhuo Xie on 2023-10-23.
//

import Foundation

class PokemonAccessService {
    
    func getPokemon() -> [Pokemon] {
        let data: PokemonPage = Bundle.main.decode(file: "pokemon.json")
        let pokemon: [Pokemon] = data.results
        
        return pokemon
    }
    
    func get150Pokemon( _ completion:@escaping ([Pokemon]) -> () ) {
        Bundle.main.fetchData(url: "https://pokeapi.co/api/v2/pokemon?limit=151", model: PokemonPage.self) { data in
            let pokeList: [Pokemon] = data.results
            completion(pokeList)
        } failure: { error in
            print(error)
        }
    }

    func getDetailedPokemon(id: Int, _ completion:@escaping (DetailedPokemon) -> () ){
        Bundle.main.fetchData(url: "https://pokeapi.co/api/v2/pokemon/\(id)/", model: DetailedPokemon.self){
            data in
            completion(data)
        } failure: {
            error in
            print(error)
        }
    }
}
