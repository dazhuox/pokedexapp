//
//  PokemonModel.swift
//  Pokedex2023
//
//  Created by Da Zhuo Xie on 2023-10-23.
//

import Foundation

struct PokemonPage: Codable {
    let count: Int
    let next: String
    let results: [Pokemon]
}

struct Pokemon: Codable, Identifiable, Equatable{
    let id = UUID()
    let name: String
    let url: String
    
    enum CodingKeys: String, CodingKey {
        case name
        case url
    }
    
    static var samplePokemon = Pokemon(name: "bulbasaur", url: "https://pokeapi.co/api/v2/pokemon/1/")
}

struct DetailedPokemon: Codable {
    let id: Int
    let height: Int
    let weight: Int
}
